package tech.powerjob.server.common.timewheel;

/**
 * 时间任务接口
 *
 * @author tjq
 * @since 2020/4/2
 */
@FunctionalInterface
public interface TimerTask extends Runnable {
}
