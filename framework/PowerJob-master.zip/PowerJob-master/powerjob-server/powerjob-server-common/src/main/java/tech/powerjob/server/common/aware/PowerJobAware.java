package tech.powerjob.server.common.aware;

/**
 * PowerJobAware
 *
 * @author tjq
 * @since 2022/9/12
 */
public interface PowerJobAware {
}
