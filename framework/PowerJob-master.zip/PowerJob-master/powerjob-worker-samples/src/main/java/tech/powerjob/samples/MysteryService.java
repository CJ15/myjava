package tech.powerjob.samples;

import org.springframework.stereotype.Service;

/**
 * 神秘服务
 *
 * @author tjq
 * @since 2020/4/18
 */
@Service
public class MysteryService {

    public String hasaki() {
        return "面对疾风吧～";
    }

}
